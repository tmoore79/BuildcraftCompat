package buildcraft.network;

public class PacketIds {
	// Propolis pipe
	public static final byte PROP_SEND_FILTER_SET = 120;
	public static final byte PROP_REQUEST_FILTER_SET = 121;
	public static final byte PROP_SEND_FILTER_CHANGE_GENOME = 122;
	public static final byte PROP_SEND_FILTER_CHANGE_TYPE = 123;
}
