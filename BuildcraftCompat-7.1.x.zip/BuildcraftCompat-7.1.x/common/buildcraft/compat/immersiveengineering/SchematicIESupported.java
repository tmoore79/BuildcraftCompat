package buildcraft.compat.immersiveengineering;

import buildcraft.api.blueprints.Schematic;

public class SchematicIESupported extends SchematicIEBase {
	// TODO
}
