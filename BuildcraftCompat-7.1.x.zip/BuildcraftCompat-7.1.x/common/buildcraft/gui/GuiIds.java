package buildcraft.gui;

public class GuiIds {
	public static final int PIPE_APIARIST = 0;
}
