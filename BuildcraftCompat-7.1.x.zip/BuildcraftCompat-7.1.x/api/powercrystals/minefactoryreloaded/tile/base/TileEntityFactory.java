package powercrystals.minefactoryreloaded.tile.base;

import net.minecraft.tileentity.TileEntity;

public class TileEntityFactory extends TileEntity {
	public boolean isActive() {
		return false;
	}
}
