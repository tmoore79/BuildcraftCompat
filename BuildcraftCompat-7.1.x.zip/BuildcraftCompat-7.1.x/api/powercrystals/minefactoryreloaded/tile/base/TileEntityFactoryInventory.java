package powercrystals.minefactoryreloaded.tile.base;

public class TileEntityFactoryInventory extends TileEntityFactory {
	public boolean hasDrops() {
		return false;
	}
}
