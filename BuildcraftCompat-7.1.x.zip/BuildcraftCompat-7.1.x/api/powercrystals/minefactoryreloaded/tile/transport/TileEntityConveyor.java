package powercrystals.minefactoryreloaded.tile.transport;

import net.minecraft.tileentity.TileEntity;

public class TileEntityConveyor extends TileEntity {
	public boolean getConveyorReversed() {
		return false;
	}

	public boolean getConveyorActive() {
		return false;
	}
}
