package mods.immibis.microblocks.api;


public enum EnumPositionClass {
	Centre,
	Face,
	Edge,
	Corner,
	Post,
}
