package mods.immibis.microblocks.api;


public enum EnumPartClass {
	Centre,
	Panel,
	HollowPanel,
	Strip,
	Corner
}
