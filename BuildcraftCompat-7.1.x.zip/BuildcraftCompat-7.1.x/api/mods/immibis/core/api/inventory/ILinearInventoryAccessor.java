package mods.immibis.core.api.inventory;

public interface ILinearInventoryAccessor extends IInventoryAccessor {

}
