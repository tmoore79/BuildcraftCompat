/**
 * Copyright (c) defeatedcrow, 2013
 * URL:http://forum.minecraftuser.jp/viewtopic.php?f=13&t=17657
 *
 * Apple&Milk&Tea! is distributed under the terms of the Minecraft Mod Public License 1.0, or MMPL.
 * Please check the License(MMPL_1.0).txt included in the package file of this Mod.
 */

@API(apiVersion="2.6", owner="DCsAppleMilk", provides="AppleMilkTeaAPI|energy")
package mods.defeatedcrow.api.energy;
import cpw.mods.fml.common.API;
