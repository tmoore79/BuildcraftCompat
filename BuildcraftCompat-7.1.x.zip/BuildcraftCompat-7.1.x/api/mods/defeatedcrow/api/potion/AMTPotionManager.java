package mods.defeatedcrow.api.potion;

public class AMTPotionManager {
	
	public static IPotionGetter manager;
	
	private AMTPotionManager(){}

}
