package mods.defeatedcrow.api.recipe;

/** This interface will be soon deleted, typo causes ... */
@Deprecated
public interface IProsessorRecipe extends IProcessorRecipe{

}
