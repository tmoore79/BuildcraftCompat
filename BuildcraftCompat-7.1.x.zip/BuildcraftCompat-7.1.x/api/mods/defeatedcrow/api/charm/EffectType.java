package mods.defeatedcrow.api.charm;

public enum EffectType {
	
	Player,
	
	EntityLiving,
	
	Block,
	
	Alt;

}
