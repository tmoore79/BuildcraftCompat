package mods.defeatedcrow.api.charge;

public final class ChargeItemManager {
	
	public static IChargeItemRegister chargeItem;
	
	private ChargeItemManager(){}

}
