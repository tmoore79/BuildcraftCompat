BuildcraftCompat
================

This mod is implementing third party mod compatibility and integration layers with BuildCraft.
